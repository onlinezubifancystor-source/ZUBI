class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1>
            <p className="text-gray-600 mb-4">We're sorry, but something unexpected happened.</p>
            <button onClick={() => window.location.reload()} className="px-6 py-3 bg-[var(--primary-color)] text-white rounded-lg">
              Reload Page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function App() {
  try {
    const [gameState, setGameState] = React.useState('setup');
    const [playerName, setPlayerName] = React.useState('');
    const [language, setLanguage] = React.useState('english');
    const [subject, setSubject] = React.useState('');
    const [level, setLevel] = React.useState('');
    const [score, setScore] = React.useState(0);
    const [treasuresFound, setTreasuresFound] = React.useState(0);
    const [openedTiles, setOpenedTiles] = React.useState([]);
    const [currentSessionId, setCurrentSessionId] = React.useState(null);
    const [autoSave, setAutoSave] = React.useState(true);

    const saveGameProgress = async () => {
      if (!autoSave || gameState !== 'playing') return;
      
      try {
        const sessionData = {
          PlayerName: playerName,
          Language: language,
          Subject: subject,
          Level: level,
          Score: score,
          TreasuresFound: treasuresFound,
          OpenedTiles: openedTiles.join(','),
          GameStatus: 'playing'
        };

        if (currentSessionId) {
          await trickleUpdateObject('game_session', currentSessionId, sessionData);
        } else {
          const session = await trickleCreateObject('game_session', sessionData);
          setCurrentSessionId(session.objectId);
        }
      } catch (error) {
        console.error('Error saving game:', error);
      }
    };

    React.useEffect(() => {
      if (gameState === 'playing' && autoSave) {
        saveGameProgress();
      }
    }, [score, treasuresFound, openedTiles, autoSave]);

    const startGame = async () => {
      setGameState('playing');
      setScore(0);
      setTreasuresFound(0);
      setOpenedTiles([]);
      setCurrentSessionId(null);
    };

    const resetGame = () => {
      setGameState('setup');
      setPlayerName('');
      setSubject('');
      setLevel('');
      setScore(0);
      setTreasuresFound(0);
      setOpenedTiles([]);
      setCurrentSessionId(null);
    };

    const completeGame = async () => {
      if (currentSessionId && autoSave) {
        try {
          await trickleUpdateObject('game_session', currentSessionId, {
            GameStatus: 'completed'
          });
        } catch (error) {
          console.error('Error completing game:', error);
        }
      }
      setGameState('complete');
    };

    return (
      <div className="min-h-screen p-5" data-name="app" data-file="app.js">
        <div className="max-w-4xl mx-auto bg-white rounded-3xl shadow-2xl overflow-hidden">
          <div className="gradient-header p-8 text-center text-white">
            <h1 className="text-4xl font-bold mb-2 drop-shadow-lg">
              {translations[language]?.title || 'Educational Adventure - Treasure Hunt'}
            </h1>
            <p className="text-lg opacity-90">
              {translations[language]?.subtitle || '🎓 Choose your subject and start learning! 🏴‍☠️💎'}
            </p>
          </div>

          {gameState === 'setup' && (
            <SetupScreen
              playerName={playerName}
              setPlayerName={setPlayerName}
              language={language}
              setLanguage={setLanguage}
              subject={subject}
              setSubject={setSubject}
              level={level}
              setLevel={setLevel}
              onStart={startGame}
            />
          )}

          {gameState === 'playing' && (
            <GameScreen
              playerName={playerName}
              language={language}
              subject={subject}
              level={level}
              score={score}
              setScore={setScore}
              treasuresFound={treasuresFound}
              setTreasuresFound={setTreasuresFound}
              openedTiles={openedTiles}
              setOpenedTiles={setOpenedTiles}
              onComplete={completeGame}
              autoSave={autoSave}
              setAutoSave={setAutoSave}
              onLoadGame={(session) => {
                setPlayerName(session.objectData.PlayerName);
                setLanguage(session.objectData.Language);
                setSubject(session.objectData.Subject);
                setLevel(session.objectData.Level);
                setScore(session.objectData.Score);
                setTreasuresFound(session.objectData.TreasuresFound);
                setOpenedTiles(session.objectData.OpenedTiles ? session.objectData.OpenedTiles.split(',').map(Number) : []);
                setCurrentSessionId(session.objectId);
                setGameState('playing');
              }}
            />
          )}

          {gameState === 'complete' && (
            <GameComplete
              playerName={playerName}
              language={language}
              score={score}
              treasuresFound={treasuresFound}
              onPlayAgain={resetGame}
            />
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('App component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);