When making updates to the project

- Check if the changes affect the project structure, features, or functionality
- Update the README.md in trickle/notes to reflect:
  - New features added
  - Changes to game flow or mechanics
  - Updates to technical stack or dependencies
  - Modified project structure
  - New future enhancement ideas
- Keep the README concise but informative
- Maintain consistent formatting and sections