# Educational Adventure - Treasure Hunt

An interactive educational game that combines learning with adventure through answering questions across multiple subjects.

## Features

- **Multi-language Support**: English and Nepali
- **Multiple Subjects**: Mathematics, Science, English, Social Studies, and Nepali
- **Three Difficulty Levels**: Easy, Medium, and Hard
- **Interactive Treasure Grid**: 24 treasure tiles to unlock
- **Score Tracking**: Earn points for correct answers
- **Real-time Auto-save**: Automatically saves game progress to database
- **Game History**: View and continue previous game sessions
- **Responsive Design**: Works on desktop, tablet, and mobile devices

## Game Flow

1. **Setup Screen**: Players enter their name, select language, subject, and difficulty level
2. **Game Screen**: Players click treasure tiles to reveal questions
3. **Question Modal**: Answer questions to unlock treasures and earn points
4. **Completion Screen**: Celebrate success and review final score

## Technical Stack

- React 18 for UI components
- TailwindCSS for styling
- Lucide icons for visual elements
- Modular component architecture

## Project Structure

- `index.html` - Main entry point
- `app.js` - Core application logic and state management
- `components/` - Reusable UI components
  - `SetupScreen.js` - Game configuration interface
  - `GameScreen.js` - Main gameplay interface with controls
  - `GameHistory.js` - Game history and save management
  - `QuestionModal.js` - Question display and answer input
  - `GameComplete.js` - Game completion celebration
- `utils/` - Helper functions and data
  - `translations.js` - Multi-language translation data
  - `questionGenerator.js` - Dynamic question generation logic

## Scoring System

- Each correct answer: +10 points
- Total treasures to find: 24
- Maximum possible score: 240 points

## Database Integration

- Uses Trickle database for persistent storage
- Stores game sessions with player info, progress, and scores
- Auto-save functionality with toggle control
- Load and continue previous games from history

## Future Enhancements

- Leaderboard system with top scores
- More subjects and languages
- Customizable treasure grid sizes
- Sound effects and animations
- Multiplayer mode
