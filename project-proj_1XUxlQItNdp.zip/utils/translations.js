const translations = {
  english: {
    title: 'Educational Adventure - Treasure Hunt',
    subtitle: '🎓 Choose your subject and start learning! 🏴‍☠️💎',
    playerNameLabel: 'Your Name:',
    selectLanguage: 'Select Language:',
    selectSubject: 'Select Subject:',
    selectLevel: 'Select Difficulty:',
    startButton: 'Start Adventure!',
    score: 'Score',
    treasures: 'Treasures',
    found: 'Found',
    questionPrompt: 'What is',
    submitAnswer: 'Submit',
    cancel: 'Cancel',
    correct: '🎉 Correct! Great job!',
    incorrect: '❌ Incorrect. The answer is',
    gameComplete: '🏆 Congratulations!',
    finalScore: 'Final Score',
    playAgain: 'Play Again',
    subjects: {
      math: 'Mathematics',
      science: 'Science',
      english: 'English',
      social: 'Social Studies',
      nepali: 'Nepali'
    },
    levels: {
      easy: 'Easy',
      medium: 'Medium',
      hard: 'Hard'
    }
  },
  nepali: {
    title: 'शैक्षिक साहसिक - खजाना खोज',
    subtitle: '🎓 आफ्नो विषय छान्नुहोस् र सिक्न सुरु गर्नुहोस्! 🏴‍☠️💎',
    playerNameLabel: 'तपाईंको नाम:',
    selectLanguage: 'भाषा चयन गर्नुहोस्:',
    selectSubject: 'विषय चयन गर्नुहोस्:',
    selectLevel: 'कठिनाई चयन गर्नुहोस्:',
    startButton: 'साहसिक सुरु गर्नुहोस्!',
    score: 'अंक',
    treasures: 'खजाना',
    found: 'फेला पारियो',
    questionPrompt: 'के हो',
    submitAnswer: 'पेश गर्नुहोस्',
    cancel: 'रद्द गर्नुहोस्',
    correct: '🎉 सही! राम्रो काम!',
    incorrect: '❌ गलत। उत्तर हो',
    gameComplete: '🏆 बधाई छ!',
    finalScore: 'अन्तिम अंक',
    playAgain: 'फेरि खेल्नुहोस्',
    subjects: {
      math: 'गणित',
      science: 'विज्ञान',
      english: 'अंग्रेजी',
      social: 'सामाजिक अध्ययन',
      nepali: 'नेपाली'
    },
    levels: {
      easy: 'सजिलो',
      medium: 'मध्यम',
      hard: 'कठिन'
    }
  }
};