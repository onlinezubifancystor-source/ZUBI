const questionGenerator = {
  generateQuestion(subject, level) {
    const generators = {
      math: this.generateMathQuestion,
      science: this.generateScienceQuestion,
      english: this.generateEnglishQuestion,
      social: this.generateSocialQuestion,
      nepali: this.generateNepaliQuestion
    };

    const generator = generators[subject] || generators.math;
    return generator.call(this, level);
  },

  generateMathQuestion(level) {
    const ranges = {
      easy: { min: 1, max: 10 },
      medium: { min: 10, max: 50 },
      hard: { min: 50, max: 100 }
    };

    const range = ranges[level] || ranges.easy;
    const num1 = Math.floor(Math.random() * (range.max - range.min)) + range.min;
    const num2 = Math.floor(Math.random() * (range.max - range.min)) + range.min;
    const operations = ['+', '-', '×'];
    const operation = operations[Math.floor(Math.random() * operations.length)];

    let answer;
    let question = `${num1} ${operation} ${num2}`;

    if (operation === '+') answer = num1 + num2;
    else if (operation === '-') answer = num1 - num2;
    else answer = num1 * num2;

    return { question, answer };
  },

  generateScienceQuestion(level) {
    const questions = {
      easy: [
        { q: 'How many legs does a spider have?', a: 8 },
        { q: 'How many planets in our solar system?', a: 8 },
        { q: 'How many colors in a rainbow?', a: 7 }
      ],
      medium: [
        { q: 'Boiling point of water (°C)?', a: 100 },
        { q: 'Number of bones in human body?', a: 206 },
        { q: 'Speed of light (100,000 km/s)?', a: 300 }
      ],
      hard: [
        { q: 'Atomic number of Carbon?', a: 6 },
        { q: 'Number of chromosomes in humans?', a: 46 },
        { q: 'Temperature of absolute zero (°C)?', a: -273 }
      ]
    };

    const levelQuestions = questions[level] || questions.easy;
    const selected = levelQuestions[Math.floor(Math.random() * levelQuestions.length)];
    return { question: selected.q, answer: selected.a };
  },

  generateEnglishQuestion(level) {
    const questions = {
      easy: [
        { q: 'Letters in "CAT"?', a: 3 },
        { q: 'Vowels in "APPLE"?', a: 2 },
        { q: 'Words in "I am happy"?', a: 3 }
      ],
      medium: [
        { q: 'Letters in "EDUCATION"?', a: 9 },
        { q: 'Syllables in "beautiful"?', a: 3 },
        { q: 'Letters in "SCHOOL"?', a: 6 }
      ],
      hard: [
        { q: 'Letters in "UNPRECEDENTED"?', a: 14 },
        { q: 'Syllables in "organization"?', a: 5 },
        { q: 'Letters in "SOPHISTICATED"?', a: 13 }
      ]
    };

    const levelQuestions = questions[level] || questions.easy;
    const selected = levelQuestions[Math.floor(Math.random() * levelQuestions.length)];
    return { question: selected.q, answer: selected.a };
  },

  generateSocialQuestion(level) {
    const questions = {
      easy: [
        { q: 'Continents on Earth?', a: 7 },
        { q: 'Days in a week?', a: 7 },
        { q: 'Months in a year?', a: 12 }
      ],
      medium: [
        { q: 'States in USA?', a: 50 },
        { q: 'Countries in Europe?', a: 44 },
        { q: 'Provinces in Nepal?', a: 7 }
      ],
      hard: [
        { q: 'UN member countries?', a: 193 },
        { q: 'Countries in Africa?', a: 54 },
        { q: 'Districts in Nepal?', a: 77 }
      ]
    };

    const levelQuestions = questions[level] || questions.easy;
    const selected = levelQuestions[Math.floor(Math.random() * levelQuestions.length)];
    return { question: selected.q, answer: selected.a };
  },

  generateNepaliQuestion(level) {
    const questions = {
      easy: [
        { q: 'नेपाली स्वर संख्या?', a: 12 },
        { q: 'हप्तामा दिन संख्या?', a: 7 },
        { q: 'वर्षमा महिना संख्या?', a: 12 }
      ],
      medium: [
        { q: 'नेपालको प्रदेश संख्या?', a: 7 },
        { q: 'नेपाली वर्णमाला अक्षर?', a: 36 },
        { q: 'एभरेस्ट उचाइ (हजार मिटर)?', a: 8 }
      ],
      hard: [
        { q: 'नेपालको जिल्ला संख्या?', a: 77 },
        { q: 'नेपाली व्यञ्जन संख्या?', a: 33 },
        { q: 'नेपाल स्थापना वर्ष (ई.स.)?', a: 1768 }
      ]
    };

    const levelQuestions = questions[level] || questions.easy;
    const selected = levelQuestions[Math.floor(Math.random() * levelQuestions.length)];
    return { question: selected.q, answer: selected.a };
  }
};