function GameComplete({ playerName, language, score, treasuresFound, onPlayAgain }) {
  try {
    const t = translations[language] || translations.english;

    return (
      <div className="p-12 text-center" data-name="game-complete" data-file="components/GameComplete.js">
        <div className="bg-gradient-to-br from-purple-600 to-purple-800 rounded-3xl p-12 text-white">
          <div className="text-7xl mb-6">🏆</div>
          <h2 className="text-4xl font-bold mb-4">{t.gameComplete}</h2>
          <p className="text-2xl mb-4">👋 {playerName}</p>
          <div className="text-3xl font-bold my-8">
            {t.finalScore}: {score}
          </div>
          <div className="text-2xl mb-8">
            {t.treasures} {t.found}: {treasuresFound}
          </div>
          <button
            onClick={onPlayAgain}
            className="px-12 py-5 text-xl bg-white text-purple-700 rounded-2xl hover:shadow-2xl transition-all font-bold"
          >
            {t.playAgain}
          </button>
        </div>
      </div>
    );
  } catch (error) {
    console.error('GameComplete component error:', error);
    return null;
  }
}