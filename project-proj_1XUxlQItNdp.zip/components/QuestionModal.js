function QuestionModal({ question, language, onAnswer, onCancel }) {
  try {
    const [answer, setAnswer] = React.useState('');
    const [result, setResult] = React.useState(null);
    const t = translations[language] || translations.english;

    const handleSubmit = () => {
      const userAnswer = parseInt(answer);
      const isCorrect = userAnswer === question.answer;
      setResult({ isCorrect, correctAnswer: question.answer });
      
      setTimeout(() => {
        onAnswer(isCorrect);
        setResult(null);
        setAnswer('');
      }, 2000);
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4" data-name="question-modal" data-file="components/QuestionModal.js">
        <div className="bg-white rounded-3xl p-10 text-center max-w-lg w-full animate-slide-in">
          <h3 className="text-4xl font-bold text-gray-800 mb-6">{t.questionPrompt}</h3>
          <div className="text-5xl font-bold text-[var(--primary-color)] my-8">
            {question.question}
          </div>

          {!result && (
            <div>
              <input
                type="number"
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && answer && handleSubmit()}
                className="px-6 py-4 text-3xl border-3 border-gray-300 rounded-xl text-center w-48 focus:outline-none focus:border-[var(--accent-color)] mb-6"
                placeholder="?"
                autoFocus
              />

              <div className="flex gap-4 justify-center">
                <button
                  onClick={handleSubmit}
                  disabled={!answer}
                  className="px-8 py-4 text-lg bg-[var(--accent-color)] text-white rounded-xl hover:bg-opacity-90 disabled:opacity-50"
                >
                  {t.submitAnswer}
                </button>
                <button
                  onClick={onCancel}
                  className="px-8 py-4 text-lg bg-gray-400 text-white rounded-xl hover:bg-gray-500"
                >
                  {t.cancel}
                </button>
              </div>
            </div>
          )}

          {result && (
            <div className={`p-6 rounded-xl text-xl font-bold ${
              result.isCorrect ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
              {result.isCorrect ? t.correct : `${t.incorrect} ${result.correctAnswer}`}
            </div>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('QuestionModal component error:', error);
    return null;
  }
}