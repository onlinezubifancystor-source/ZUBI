function GameHistory({ language, onClose, onLoadGame }) {
  try {
    const [sessions, setSessions] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const t = translations[language] || translations.english;

    React.useEffect(() => {
      loadSessions();
    }, []);

    const loadSessions = async () => {
      try {
        setLoading(true);
        const result = await trickleListObjects('game_session', 50, true);
        setSessions(result.items);
      } catch (error) {
        console.error('Error loading sessions:', error);
      } finally {
        setLoading(false);
      }
    };

    const handleDelete = async (sessionId) => {
      try {
        await trickleDeleteObject('game_session', sessionId);
        await loadSessions();
      } catch (error) {
        console.error('Error deleting session:', error);
      }
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4" data-name="game-history" data-file="components/GameHistory.js">
        <div className="bg-white rounded-3xl p-8 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-3xl font-bold text-gray-800">Game History</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700 text-2xl">
              ✕
            </button>
          </div>

          {loading && (
            <div className="text-center py-8">
              <div className="inline-block w-12 h-12 border-4 border-gray-300 border-t-[var(--primary-color)] rounded-full animate-spin"></div>
            </div>
          )}

          {!loading && sessions.length === 0 && (
            <p className="text-center text-gray-500 py-8">No saved games yet</p>
          )}

          {!loading && sessions.length > 0 && (
            <div className="space-y-4">
              {sessions.map((session) => (
                <div key={session.objectId} className="bg-gray-50 rounded-xl p-4 border-2 border-gray-200 hover:border-[var(--accent-color)] transition-all">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="text-xl font-bold text-gray-800">{session.objectData.PlayerName}</h3>
                      <p className="text-sm text-gray-600">
                        {t.subjects[session.objectData.Subject]} - {t.levels[session.objectData.Level]}
                      </p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                      session.objectData.GameStatus === 'completed' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {session.objectData.GameStatus === 'completed' ? '✓ Completed' : '▶ Playing'}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-sm text-gray-600 mb-3">
                    <span>Score: {session.objectData.Score}</span>
                    <span>Treasures: {session.objectData.TreasuresFound}/24</span>
                    <span>{new Date(session.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex gap-2">
                    {session.objectData.GameStatus === 'playing' && (
                      <button
                        onClick={() => {
                          onLoadGame(session);
                          onClose();
                        }}
                        className="flex-1 px-4 py-2 bg-[var(--accent-color)] text-white rounded-lg hover:bg-opacity-90 transition-all"
                      >
                        Continue
                      </button>
                    )}
                    <button
                      onClick={() => handleDelete(session.objectId)}
                      className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-all"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('GameHistory component error:', error);
    return null;
  }
}