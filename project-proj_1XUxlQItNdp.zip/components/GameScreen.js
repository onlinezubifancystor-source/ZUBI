function GameScreen({ playerName, language, subject, level, score, setScore, treasuresFound, setTreasuresFound, openedTiles, setOpenedTiles, onComplete, autoSave, setAutoSave, onLoadGame }) {
  try {
    const [currentQuestion, setCurrentQuestion] = React.useState(null);
    const [selectedTile, setSelectedTile] = React.useState(null);
    const [showHistory, setShowHistory] = React.useState(false);
    const t = translations[language] || translations.english;
    const totalTreasures = 24;

    const handleTileClick = (index) => {
      if (openedTiles.includes(index)) return;
      const question = questionGenerator.generateQuestion(subject, level);
      setCurrentQuestion(question);
      setSelectedTile(index);
    };

    const handleAnswer = (isCorrect) => {
      if (isCorrect) {
        setScore(score + 10);
        setTreasuresFound(treasuresFound + 1);
        setOpenedTiles([...openedTiles, selectedTile]);
        
        if (treasuresFound + 1 >= totalTreasures) {
          setTimeout(() => onComplete(), 1500);
        }
      }
      setCurrentQuestion(null);
      setSelectedTile(null);
    };

    return (
      <div className="p-8" data-name="game-screen" data-file="components/GameScreen.js">
        <div className="flex justify-center gap-3 mb-6 flex-wrap">
          <button
            onClick={() => setShowHistory(true)}
            className="px-4 py-2 bg-white text-gray-700 rounded-lg border-2 border-gray-300 hover:border-[var(--accent-color)] transition-all flex items-center gap-2"
          >
            <div className="icon-history text-lg"></div>
            <span>History</span>
          </button>
          <div className="flex items-center gap-2 px-4 py-2 bg-white rounded-lg border-2 border-gray-300">
            <span className="text-sm text-gray-700">Auto-save</span>
            <button
              onClick={() => setAutoSave(!autoSave)}
              className={`w-12 h-6 rounded-full transition-all ${autoSave ? 'bg-[var(--accent-color)]' : 'bg-gray-300'}`}
            >
              <div className={`w-5 h-5 bg-white rounded-full transition-all ${autoSave ? 'ml-6' : 'ml-0.5'}`}></div>
            </button>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-white rounded-lg border-2 border-gray-300">
            <div className={`icon-${autoSave ? 'check-circle' : 'circle'} text-lg ${autoSave ? 'text-green-600' : 'text-gray-400'}`}></div>
            <span className="text-sm text-gray-600">{autoSave ? 'Saving...' : 'Not saving'}</span>
          </div>
        </div>

        <div className="bg-gray-100 rounded-2xl p-6 mb-8 flex justify-around items-center flex-wrap gap-4">
          <div className="text-center">
            <div className="text-4xl font-bold text-[var(--secondary-color)]">{score}</div>
            <div className="text-sm text-gray-600 mt-1">{t.score}</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-[var(--secondary-color)]">{treasuresFound}/{totalTreasures}</div>
            <div className="text-sm text-gray-600 mt-1">{t.treasures} {t.found}</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-700">👋 {playerName}</div>
            <div className="text-sm text-gray-600 mt-1">{t.subjects[subject]}</div>
          </div>
        </div>

        <div className="grid grid-cols-6 gap-3 max-w-2xl mx-auto">
          {Array.from({ length: totalTreasures }).map((_, index) => (
            <button
              key={index}
              onClick={() => handleTileClick(index)}
              disabled={openedTiles.includes(index)}
              className={`aspect-square text-3xl rounded-xl transition-all ${
                openedTiles.includes(index)
                  ? 'bg-green-200 cursor-default'
                  : 'treasure-gradient hover:scale-105 hover:shadow-xl cursor-pointer'
              }`}
            >
              {openedTiles.includes(index) ? '✓' : '💎'}
            </button>
          ))}
        </div>

        {currentQuestion && (
          <QuestionModal
            question={currentQuestion}
            language={language}
            onAnswer={handleAnswer}
            onCancel={() => {
              setCurrentQuestion(null);
              setSelectedTile(null);
            }}
          />
        )}

        {showHistory && (
          <GameHistory
            language={language}
            onClose={() => setShowHistory(false)}
            onLoadGame={onLoadGame}
          />
        )}
      </div>
    );
  } catch (error) {
    console.error('GameScreen component error:', error);
    return null;
  }
}