function SetupScreen({ playerName, setPlayerName, language, setLanguage, subject, setSubject, level, setLevel, onStart }) {
  try {
    const t = translations[language] || translations.english;
    const canStart = playerName.trim() && subject && level;

    return (
      <div className="p-8" data-name="setup-screen" data-file="components/SetupScreen.js">
        <div className="text-center mb-8">
          <label className="block text-xl font-bold text-gray-700 mb-4">
            {t.playerNameLabel}
          </label>
          <input
            type="text"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            className="px-6 py-3 text-lg border-3 border-gray-300 rounded-xl text-center w-80 max-w-full focus:outline-none focus:border-[var(--primary-color)]"
            placeholder="Enter your name"
          />
        </div>

        <div className="mb-8">
          <h3 className="text-xl font-bold text-center text-gray-700 mb-4">{t.selectLanguage}</h3>
          <div className="flex gap-4 justify-center flex-wrap">
            {['english', 'nepali'].map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={`px-6 py-4 text-lg rounded-xl transition-all ${
                  language === lang
                    ? 'bg-[var(--primary-color)] text-white border-2 border-[var(--primary-color)]'
                    : 'bg-gray-100 text-gray-700 border-2 border-transparent hover:shadow-lg'
                }`}
              >
                {lang === 'english' ? 'English' : 'नेपाली'}
              </button>
            ))}
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-xl font-bold text-center text-gray-700 mb-4">{t.selectSubject}</h3>
          <div className="flex gap-4 justify-center flex-wrap max-w-3xl mx-auto">
            {Object.keys(t.subjects).map((subj) => (
              <button
                key={subj}
                onClick={() => setSubject(subj)}
                className={`px-6 py-4 text-lg rounded-xl transition-all min-w-[140px] ${
                  subject === subj
                    ? 'bg-[var(--secondary-color)] text-white border-2 border-[var(--secondary-color)]'
                    : 'bg-gray-100 text-gray-700 border-2 border-transparent hover:shadow-lg'
                }`}
              >
                {t.subjects[subj]}
              </button>
            ))}
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-xl font-bold text-center text-gray-700 mb-4">{t.selectLevel}</h3>
          <div className="flex gap-4 justify-center flex-wrap">
            {Object.keys(t.levels).map((lv) => (
              <button
                key={lv}
                onClick={() => setLevel(lv)}
                className={`px-6 py-4 text-lg rounded-xl transition-all min-w-[140px] ${
                  level === lv
                    ? 'bg-[var(--accent-color)] text-white border-2 border-[var(--accent-color)]'
                    : 'bg-gray-100 text-gray-700 border-2 border-transparent hover:shadow-lg'
                }`}
              >
                {t.levels[lv]}
              </button>
            ))}
          </div>
        </div>

        <div className="text-center">
          <button
            onClick={onStart}
            disabled={!canStart}
            className="gradient-button px-12 py-5 text-xl text-white rounded-2xl transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-xl"
          >
            {t.startButton}
          </button>
        </div>
      </div>
    );
  } catch (error) {
    console.error('SetupScreen component error:', error);
    return null;
  }
}